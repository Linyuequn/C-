#ifndef __MOTOR_H
#define __MOTOR_H

void Motor_Init(void);
void Motor_Set_Current(uint16_t Value1,uint16_t Value2,uint16_t Value3,uint16_t Value4);
uint16_t Motor_Read_Current(void);
uint16_t Motor_Read_Angle(void);

#endif
