#include "stm32f10x.h"                  

typedef struct {
    float Kp;    // 比例增益
    float Ki;    // 积分增益
    float Kd;    // 微分增益

    float target;   // 设定目标
    float feedback; // 反馈值

    float last_error;   // 上一次误差
    float integral;     // 积分项
	float integral_limit;     // 积分项限制
	
} PID_TypeDef;

void PID_Init(PID_TypeDef *pid, float kp, float ki, float kd, float integral_limit) 
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
	pid->integral_limit = integral_limit;

    pid->target = 0;
    pid->feedback = 0;

    pid->last_error = 0;
    pid->integral = 0;
}

void PID_UpdateParameters(PID_TypeDef *pid, float kp, float ki, float kd)   //定义一个函数来更新PID的值
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
}

float PID_Calculate(PID_TypeDef *pid, float setpoint, float actual)  //需要传入目标值和当前值
{
	
	pid->target = setpoint;	
    float error = setpoint - actual;                //距离目标的误差--比例项
    pid->integral += error;                         //积累下来的积分项
	
	//积分项限幅
	if (pid->integral > pid->integral_limit) 
	{
		pid->integral = pid->integral_limit;
	} 
	else if (pid->integral < -pid->integral_limit) 
	{
        pid->integral = -pid->integral_limit;
    }
	
    float derivative = (error - pid->last_error);       //微分项

    pid->feedback  = (pid->Kp * error) + (pid->Ki * pid->integral) + (pid->Kd * derivative);

	pid->last_error = error;  //把当前误差作为下一次计算的上次误差

    return pid->feedback;
}




















