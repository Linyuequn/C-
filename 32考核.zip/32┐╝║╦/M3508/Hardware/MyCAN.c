#include "stm32f10x.h"                  // Device header

void MyCAN_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;       //PA12（CAN_TX）--复用推挽输出
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;        //PA11（CAN_RX）--上拉输入
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	CAN_InitTypeDef CAN_InitStructure;                
	CAN_InitStructure.CAN_Prescaler = 4;             //CAN总线的预分频系数
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal;     //CAN控制器的工作模式--正常模式
	CAN_InitStructure.CAN_SJW = CAN_SJW_1tq;          //重新同步跳跃时间单元
	CAN_InitStructure.CAN_BS1 = CAN_BS1_4tq;          //时间段1和时间段2的长度
	CAN_InitStructure.CAN_BS2 = CAN_BS2_4tq;          
	CAN_InitStructure.CAN_TTCM = DISABLE;             //禁用时间触发通信模式
	CAN_InitStructure.CAN_ABOM = DISABLE;             //禁用自动总线失效管理
	CAN_InitStructure.CAN_AWUM = DISABLE;             //禁用自动唤醒模式
	CAN_InitStructure.CAN_NART = DISABLE;             //不禁止报文的自动重传
	CAN_InitStructure.CAN_RFLM = DISABLE;             //禁用FIFO锁定模式       (FIFO就是所谓的邮箱)
	CAN_InitStructure.CAN_TXFP = DISABLE;             //禁用发送FIFO的优先级
	CAN_Init(CAN1, &CAN_InitStructure);               
	
	CAN_FilterInitTypeDef CAN_FilterInitStructure;
	CAN_FilterInitStructure.CAN_FilterIdHigh = 0x0000;                    //指定了滤波器的标识符（ID）的高位（0X0000表示不过滤任何特定标识符）
	CAN_FilterInitStructure.CAN_FilterIdLow = 0x0000;                     //指定了滤波器的标识符（ID）的低位（0X0000表示不过滤任何特定标识符）
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh = 0x0000;                //指定了用于屏蔽滤波器的标识符的高位（0X0000表示不对标识符进行屏蔽）
	CAN_FilterInitStructure.CAN_FilterMaskIdLow = 0x0000;                 //指定了用于屏蔽滤波器的标识符的低位（0X0000表示不对标识符进行屏蔽）
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;  //指定了滤波器匹配的CAN帧应该存储在哪个FIFO，存储在FIFO0中
	CAN_FilterInitStructure.CAN_FilterNumber = 0;                         //指定了要配置的滤波器编号，设置为0，表示配置CAN控制器的第一个滤波器
	CAN_FilterInitStructure.CAN_FilterMode = CAN_FilterMode_IdMask;       //指定了滤波器的工作模式，IdMask表示滤波器使用标识符和屏蔽进行过滤
	CAN_FilterInitStructure.CAN_FilterScale = CAN_FilterScale_32bit;      //指定了滤波器的比例尺度，表示使用32位的标识符和屏蔽进行匹配
	CAN_FilterInitStructure.CAN_FilterActivation = ENABLE;                //启用该滤波器，使其可以过滤CAN帧
	CAN_FilterInit(&CAN_FilterInitStructure);                             //将以上配置应用到CAN控制器的滤波器上
}

void MyCAN_Transmit(uint32_t ID, uint8_t Length, uint8_t *Data)  //定义一个传输数据到CAN总线的函数（里面是先传参保存，再传输）
{
	CanTxMsg TxMessage;							//用于存储要发送的CAN消息的信息
	TxMessage.StdId = ID;    //StdId 是标准帧的标识符
	TxMessage.ExtId = ID;    //ExtId 是扩展帧的标识符
	TxMessage.IDE = CAN_Id_Standard;    //指定CAN消息的标识符类型,为标准帧模式
	TxMessage.RTR = CAN_RTR_Data;      //指定为数据帧，非遥控帧（遥控帧也称为远程帧）
	TxMessage.DLC = Length;				//即设置DLC的值，最多为8个字节
	for (uint8_t i = 0; i < Length; i ++)
	{
		TxMessage.Data[i] = Data[i];		//将Data第一个数据地址赋给结构体成员，相当于全部数据传给该成员
	}
	uint8_t TransmitMailbox = CAN_Transmit(CAN1, &TxMessage);    //向CAN总线发送消息
	while (CAN_TransmitStatus(CAN1, TransmitMailbox) != CAN_TxStatus_Ok);    ////判断指定邮箱（Mailbox）的消息发送状态，直到发送成功才跳出这个函数
}                  //因为只有一个CAN总线，所以这里是CAN1

uint8_t MyCAN_ReceiveFlag(void)
{
	if (CAN_MessagePending(CAN1, CAN_FIFO0) > 0)   //检查指定接收FIFO中是否有未处理的消息等待接收
	{
		return 1;                                  //有的话就返回1
	}
	return 0;                                      //没有的话就返回0
}

void MyCAN_Receive(uint32_t *ID, uint8_t *Length, int8_t *Data)  //接收CAN总线的消息，并将消息的ID、长度和数据存储到提供的指针变量中
{
	CanRxMsg RxMessage;							//定义一个 CanRxMsg 结构体变量 RxMessage
	
	CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);   //从CAN1模块的FIFO0中接收消息，并将消息存储到 RxMessage 变量中
	
	if (RxMessage.IDE == CAN_Id_Standard)  	    //如果接收到的消息的IDE位为标准帧格式
	{
		*ID = RxMessage.StdId;     			    //那么ID就等于标准帧11位ID
	}
	else
	{
		*ID = RxMessage.ExtId;			//那么ID就等于扩展帧的前11+后18位
	}
	
	if (RxMessage.RTR == CAN_RTR_Data)
	{
		*Length = RxMessage.DLC;
		for (uint8_t i = 0; i < *Length; i ++)
		{
			Data[i] = RxMessage.Data[i];
		}
	}
	else      							//即RxMessage = CAN_RTR_Remote;
	{
					//可直接留空
	}
}

//void CAN1_RX1_IRQHandler(void)
//{
//		//判断
//}
