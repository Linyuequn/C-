#ifndef __PID_H
#define __PID_H

typedef struct {
    float Kp;    // 比例增益
    float Ki;    // 积分增益
    float Kd;    // 微分增益

    float target;   // 设定目标
    float feedback; // 反馈值

    float last_error;   // 上一次误差
    float integral;     // 积分项
	float integral_limit;     // 积分项限制
	
} PID_TypeDef;

void PID_Init(PID_TypeDef *pid, float kp, float ki, float kd, float integral_limit);
float PID_Calculate(PID_TypeDef *pid, float setpoint, float actual);
void PID_UpdateParameters(PID_TypeDef *pid, float kp, float ki, float kd);

#endif
