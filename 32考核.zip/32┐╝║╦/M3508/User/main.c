#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "motor.h"
#include "PID.h"									


int main(void)
{
	Motor_Init();
	OLED_Init();
	
	
 
	

	while(1)
	{					
		Motor_Set_Current(10000,10000,10000,10000);//设置电机电流值

	}

}




