#include "stm32f10x.h"                 
#include "string.h"
#include "Delay.h"
#include "Serial.h"
#include "LED.h"

int main(void)
{
	
	LED_Init();			
	Serial_Init();		
	
	while (1)
	{
		if (Serial_RxFlag == 1)		//如果接收到数据包
		{
			
			if (strcmp(Serial_RxPacket, "LED_ON") == 0)			
			{
				LED1_ON();									
				Serial_SendString("LED_ON_OK\r\n");				//回传LED_ON_OK
			}
			else if (strcmp(Serial_RxPacket, "LED_OFF") == 0)	
			{
				LED1_OFF();										
				Serial_SendString("LED_OFF_OK\r\n");			//回传LED_OFF_OK
			}
			else						
			{
				Serial_SendString("ERROR_COMMAND\r\n");			//回传ERROR_COMMAND
			}
			
			Serial_RxFlag = 0;			//处理完成后，需要将接收数据包标志位清零，否则将无法接收后续数据包
		}
	}
}
