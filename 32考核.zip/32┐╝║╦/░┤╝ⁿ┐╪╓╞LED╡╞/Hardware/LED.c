#include "stm32f10x.h"                  // Device header


void LED_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;    //将PA1,2,3,4,5引脚初始化为推挽输出
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						
	

	GPIO_ResetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5);	//设置PA1,2,3,4,5引脚为低电平
}

void LED_ON(uint8_t led_number)
{
    switch (led_number)
    {
        case 1:
            GPIO_SetBits(GPIOA, GPIO_Pin_1);
            break;
        case 2:
            GPIO_SetBits(GPIOA, GPIO_Pin_2);
            break;
        case 3:
            GPIO_SetBits(GPIOA, GPIO_Pin_3);
            break;
        case 4:
            GPIO_SetBits(GPIOA, GPIO_Pin_4);
            break;
        case 5:
            GPIO_SetBits(GPIOA, GPIO_Pin_5);
            break;
        default:
            break;
    }
}

void LED_OFF(uint8_t led_number)
{
    switch (led_number)
    {
        case 1:
            GPIO_ResetBits(GPIOA, GPIO_Pin_1);
            break;
        case 2:
            GPIO_ResetBits(GPIOA, GPIO_Pin_2);
            break;
        case 3:
            GPIO_ResetBits(GPIOA, GPIO_Pin_3);
            break;
        case 4:
            GPIO_ResetBits(GPIOA, GPIO_Pin_4);
            break;
        case 5:
            GPIO_ResetBits(GPIOA, GPIO_Pin_5);
            break;
        default:
            break;
    }
}
